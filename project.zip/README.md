# NEXCODE
Мобильная IDE: Kotlin + Jetpack Compose. Дашборд, проекты, редактор с подсветкой, терминал (sh), плагины, настройки.
Сборка: `gradle assembleDebug` → app/build/outputs/apk/debug/
