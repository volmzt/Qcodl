package com.nexcode.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.app.AppState
import com.nexcode.app.EditorTab
import com.nexcode.app.editor.Lang
import com.nexcode.app.editor.SyntaxTransformation

@Composable
fun EditorScreen(app: AppState) {
    val tab = app.tabs.getOrNull(app.active)
    Column(Modifier.fillMaxSize()) {
        ScreenTitle(tab?.file?.name ?: "Редактор") {
            if (tab != null) {
                IconButton(onClick = { app.save(tab) }, enabled = tab.dirty) {
                    Icon(Icons.Default.Check, contentDescription = "Сохранить", tint = if (tab.dirty) NX.Accent else NX.Dim)
                }
            }
        }
        if (tab == null) {
            Box(Modifier.padding(horizontal = 20.dp)) {
                NxCard(Modifier.fillMaxWidth(), onClick = { app.screen = Screen.Project }) {
                    Text("Нет открытых файлов", color = Color.White, fontSize = 18.sp)
                    Text("Открой файл в разделе «Проект»", color = NX.Dim, fontSize = 14.sp)
                }
            }
        } else {
            TabsRow(app)
            CodeArea(app, tab, Modifier.weight(1f))
            SymbolBar(tab)
        }
    }
}

@Composable
private fun TabsRow(app: AppState) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        app.tabs.forEachIndexed { i, t ->
            val sel = i == app.active
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier
                    .clip(shape)
                    .background(if (sel) NX.Accent.copy(alpha = 0.18f) else NX.Card)
                    .clickable { app.active = i }
                    .padding(start = 14.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    (if (t.dirty) "● " else "") + t.file.name,
                    color = if (sel) NX.Accent else Color.White, fontSize = 14.sp
                )
                IconButton(onClick = { app.close(i) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = NX.Dim, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun CodeArea(app: AppState, tab: EditorTab, modifier: Modifier) {
    val vs = rememberScrollState()
    val hs = rememberScrollState()
    val lang = remember(tab.file.name) { Lang.fromName(tab.file.name) }
    val transformation = remember(lang) { SyntaxTransformation(lang) }
    val lines = tab.value.text.count { it == '\n' } + 1
    val numbers = remember(lines) { (1..lines).joinToString("\n") }
    val base = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = app.fontSize.sp,
        lineHeight = (app.fontSize * 1.45f).sp,
        color = Color(0xFFE6E6E6)
    )
    Box(
        modifier
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(NX.Card)
    ) {
        Row(Modifier.fillMaxWidth().verticalScroll(vs).padding(vertical = 12.dp)) {
            Text(
                numbers,
                style = base.copy(color = NX.Dim, textAlign = TextAlign.End),
                modifier = Modifier.width(44.dp).padding(end = 8.dp)
            )
            Box(Modifier.weight(1f).horizontalScroll(hs)) {
                BasicTextField(
                    value = tab.value,
                    onValueChange = {
                        if (it.text != tab.value.text) tab.dirty = true
                        tab.value = it
                    },
                    textStyle = base,
                    cursorBrush = SolidColor(NX.Accent),
                    visualTransformation = transformation,
                    readOnly = tab.readOnly,
                    softWrap = false,
                    modifier = Modifier.defaultMinSize(minWidth = 300.dp, minHeight = 300.dp).padding(end = 40.dp)
                )
            }
        }
    }
}

@Composable
private fun SymbolBar(tab: EditorTab) {
    val keys = listOf("TAB", "{", "}", "(", ")", "[", "]", "<", ">", "/", "=", ";", ":", "\"", "'", "←", "→", "↑", "↓")
    val special = setOf("TAB", "←", "→", "↑", "↓")
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        keys.forEach { k ->
            Box(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(NX.Card2)
                    .clickable {
                        when (k) {
                            "TAB" -> tab.insert("  ")
                            "←" -> tab.move(-1)
                            "→" -> tab.move(1)
                            "↑" -> tab.moveLine(-1)
                            "↓" -> tab.moveLine(1)
                            else -> tab.insert(k)
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(k, color = if (k in special) NX.Accent else Color.White, fontFamily = FontFamily.Monospace, fontSize = 15.sp)
            }
        }
    }
}
