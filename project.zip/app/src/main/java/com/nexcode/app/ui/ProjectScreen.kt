package com.nexcode.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.app.AppState
import java.io.File

@Composable
fun ProjectScreen(app: AppState) {
    var dir by remember { mutableStateOf(app.repo.root) }
    var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    val entries = remember(dir, refresh) { app.repo.list(dir) }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Проект") {
            IconButton(onClick = { name = ""; dialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Создать", tint = NX.Accent)
            }
        }
        Text(
            "/" + dir.relativeTo(app.repo.root).path,
            color = NX.Dim, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
        )
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (dir != app.repo.root) {
                item {
                    NxCard(Modifier.fillMaxWidth(), onClick = { dir = dir.parentFile ?: app.repo.root }, pad = 14.dp) {
                        Text("..", color = NX.Accent, fontSize = 17.sp)
                    }
                }
            }
            items(entries, key = { it.absolutePath }) { f ->
                NxCard(Modifier.fillMaxWidth(), onClick = { if (f.isDirectory) dir = f else app.open(f) }, pad = 14.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (f.isDirectory) Icons.Default.List else Icons.Default.Edit,
                            contentDescription = null,
                            tint = if (f.isDirectory) NX.Amber else NX.Accent
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(f.name, color = Color.White, fontSize = 17.sp)
                    }
                }
            }
        }
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            containerColor = NX.Card2,
            title = { Text("Новый файл", color = Color.White) },
            text = {
                Column {
                    Text("Имя заканчивается на / — будет создана папка", color = NX.Dim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isNotEmpty() && !n.contains("..")) {
                        if (n.endsWith("/")) File(dir, n).mkdirs()
                        else File(dir, n).apply { parentFile?.mkdirs(); if (!exists()) createNewFile() }
                        refresh++
                    }
                    dialog = false
                }) { Text("Создать", color = NX.Accent) }
            },
            dismissButton = { TextButton(onClick = { dialog = false }) { Text("Отмена", color = NX.Dim) } }
        )
    }
}
