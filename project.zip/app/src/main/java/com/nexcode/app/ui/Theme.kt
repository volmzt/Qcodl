package com.nexcode.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object NX {
    val Bg = Color(0xFF0A0A0A)
    val Card = Color(0xFF161618)
    val Card2 = Color(0xFF1E1E20)
    val Accent = Color(0xFFFF6600)
    val Amber = Color(0xFFFFB300)
    val Dim = Color(0xFF999999)
}

@Composable
fun NexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NX.Accent,
            onPrimary = Color.Black,
            background = NX.Bg,
            surface = NX.Card,
            onSurface = Color.White
        ),
        content = content
    )
}
