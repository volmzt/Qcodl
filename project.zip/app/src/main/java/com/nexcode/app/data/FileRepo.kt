package com.nexcode.app.data

import android.content.Context
import java.io.File

class FileRepo(ctx: Context) {
    val root: File = File(ctx.filesDir, "projects").apply { mkdirs() }

    init {
        if (root.list().isNullOrEmpty()) seed()
    }

    private fun seed() {
        val d = File(root, "welcome").apply { mkdirs() }
        File(d, "main.py").writeText(
            "# Добро пожаловать в NEXCODE\n\ndef greet(name):\n    return 'Hello, ' + name\n\nprint(greet('world'))\n"
        )
        File(d, "index.html").writeText(
            "<!DOCTYPE html>\n<html>\n<body>\n  <h1 class=\"title\">NEXCODE</h1>\n</body>\n</html>\n"
        )
        File(d, ".env").writeText("API_URL=https://example.com\n")
        File(root, "README.md").writeText("# Мой проект\n")
    }

    fun list(dir: File): List<File> =
        dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()

    fun count(): Int = root.walkTopDown().count { it.isFile }

    /** Возвращает текст и флаг "только чтение" (для очень больших файлов читаем лишь начало). */
    fun read(f: File): Pair<String, Boolean> {
        val big = f.length() > 5_000_000
        val text = if (big) {
            f.bufferedReader().use {
                val buf = CharArray(100_000)
                val n = it.read(buf)
                String(buf, 0, maxOf(n, 0))
            }
        } else f.readText()
        return text to big
    }

    fun write(f: File, text: String) = f.writeText(text)
}
