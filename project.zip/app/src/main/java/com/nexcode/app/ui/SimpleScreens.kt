package com.nexcode.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.app.AppState

@Composable
fun PluginsScreen() {
    val plugins = listOf(
        "Neon Orange" to "Тема оформления",
        "Prettier" to "Форматтер",
        "ESLint" to "Линтер",
        "Git Gutter" to "Отметки изменений"
    )
    val on = remember { mutableStateMapOf<String, Boolean>() }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Плагины")
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Каркас: переключатели пока не подключены к функциям.", color = NX.Dim, fontSize = 13.sp)
            plugins.forEach { (n, d) ->
                NxCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(n, color = Color.White, fontSize = 17.sp)
                            Text(d, color = NX.Dim, fontSize = 13.sp)
                        }
                        Switch(
                            checked = on[n] == true,
                            onCheckedChange = { on[n] = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = NX.Accent, checkedThumbColor = Color.Black)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(app: AppState) {
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Настройки")
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            NxCard(Modifier.fillMaxWidth()) {
                Text("Размер шрифта редактора: ${app.fontSize.toInt()} sp", color = Color.White, fontSize = 16.sp)
                Slider(
                    value = app.fontSize,
                    onValueChange = { app.fontSize = it },
                    valueRange = 10f..22f,
                    colors = SliderDefaults.colors(thumbColor = NX.Accent, activeTrackColor = NX.Accent)
                )
            }
            NxCard(Modifier.fillMaxWidth()) {
                Text("NEXCODE 0.1", color = Color.White, fontSize = 16.sp)
                Text("Kotlin · Jetpack Compose", color = NX.Dim, fontSize = 13.sp)
            }
        }
    }
}
