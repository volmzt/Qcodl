package com.nexcode.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

enum class Screen(val label: String, val icon: ImageVector) {
    Home("Главная", Icons.Default.Home),
    Project("Проект", Icons.Default.List),
    Editor("Редактор", Icons.Default.Edit),
    Terminal("Терминал", Icons.Default.PlayArrow),
    Plugins("Плагины", Icons.Default.Star),
    Settings("Настройки", Icons.Default.Settings)
}

@Composable
fun NxCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    pad: Dp = 18.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .clip(shape)
            .background(NX.Card)
            .border(1.dp, Color(0x14FFFFFF), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(pad),
        content = content
    )
}

@Composable
fun ScreenTitle(text: String, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun StatCard(label: String, value: String, sub: String, progress: Float?, modifier: Modifier = Modifier) {
    NxCard(modifier) {
        Text(label, color = NX.Dim, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (progress != null) {
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                color = NX.Accent,
                trackColor = NX.Card2,
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
            )
            Spacer(Modifier.height(6.dp))
        }
        Text(sub, color = NX.Dim, fontSize = 13.sp)
    }
}

@Composable
fun FloatingNav(current: Screen, onSelect: (Screen) -> Unit) {
    val items = listOf(Screen.Home, Screen.Project, Screen.Terminal, Screen.Plugins, Screen.Settings)
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xE61E1E20))
            .border(1.dp, Color(0x26FFFFFF), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        items.forEach { s ->
            val sel = s == current || (s == Screen.Project && current == Screen.Editor)
            val itemShape = RoundedCornerShape(24.dp)
            Column(
                Modifier
                    .weight(1f)
                    .clip(itemShape)
                    .background(if (sel) NX.Accent.copy(alpha = 0.16f) else Color.Transparent)
                    .then(if (sel) Modifier.border(1.dp, NX.Accent.copy(alpha = 0.5f), itemShape) else Modifier)
                    .clickable { onSelect(s) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(s.icon, contentDescription = s.label, tint = if (sel) NX.Accent else NX.Dim)
                Text(s.label, color = if (sel) NX.Accent else NX.Dim, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}
