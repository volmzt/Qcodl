package com.nexcode.app.editor

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

object Lang {
    fun fromName(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "kt", "kts" -> "kotlin"
        "java" -> "java"
        "js", "jsx", "ts", "tsx", "mjs" -> "js"
        "py" -> "python"
        "c", "h", "cpp", "hpp", "cc" -> "cpp"
        "rs" -> "rust"
        "go" -> "go"
        "html", "xml", "svg" -> "html"
        "css" -> "css"
        "json" -> "json"
        "sh", "bash" -> "shell"
        else -> "text"
    }
}

private val KEYWORDS = mapOf(
    "kotlin" to "fun val var class object interface if else when for while return import package null true false is in as override private public data sealed suspend",
    "java" to "class interface public private protected static final void int long double boolean new return if else for while null true false import package extends implements try catch throw",
    "js" to "function const let var class if else for while return import export from default new null undefined true false async await try catch throw typeof interface type",
    "python" to "def class if elif else for while return import from as None True False try except raise with lambda yield pass in is not and or",
    "cpp" to "int long double float char void class struct if else for while return include define namespace using const static new delete nullptr true false template typename",
    "rust" to "fn let mut struct enum impl trait pub use mod if else match for while loop return self Self true false const static async await",
    "go" to "func var const type struct interface package import if else for range return go defer chan map nil true false switch case",
    "css" to "important",
    "shell" to "if then else fi for do done while case esac function export echo cd ls cat",
    "json" to "true false null"
)

private val kwCache = HashMap<String, Regex?>()
private fun kwRegex(lang: String): Regex? = kwCache.getOrPut(lang) {
    KEYWORDS[lang]?.split(' ')?.joinToString("|", "\\b(?:", ")\\b")?.toRegex()
}

private val NUM = Regex("\\b\\d+(?:\\.\\d+)?\\b")
private val STR = Regex("\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'")
private val TAG = Regex("</?[A-Za-z][\\w-]*")
private val C_SLASH = Regex("//.*|/\\*[\\s\\S]*?\\*/")
private val C_HASH = Regex("#.*")
private val C_HTML = Regex("<!--[\\s\\S]*?-->")
private val C_CSS = Regex("/\\*[\\s\\S]*?\\*/")

private val KW_COLOR = SpanStyle(color = Color(0xFFFF7A1A))
private val NUM_COLOR = SpanStyle(color = Color(0xFF80CBC4))
private val STR_COLOR = SpanStyle(color = Color(0xFFA5D6A7))
private val TAG_COLOR = SpanStyle(color = Color(0xFFFFB300))
private val COM_COLOR = SpanStyle(color = Color(0xFF6B6B6B), fontStyle = FontStyle.Italic)

fun highlight(src: String, lang: String): AnnotatedString {
    if (lang == "text" || src.length > 300_000) return AnnotatedString(src)
    return buildAnnotatedString {
        append(src)
        fun paint(r: Regex?, s: SpanStyle) {
            r?.findAll(src)?.forEach { addStyle(s, it.range.first, it.range.last + 1) }
        }
        paint(kwRegex(lang), KW_COLOR)
        paint(NUM, NUM_COLOR)
        if (lang == "html") paint(TAG, TAG_COLOR)
        paint(STR, STR_COLOR)
        val com = when (lang) {
            "python", "shell" -> C_HASH
            "html" -> C_HTML
            "css" -> C_CSS
            "json" -> null
            else -> C_SLASH
        }
        paint(com, COM_COLOR)
    }
}

class SyntaxTransformation(private val lang: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(highlight(text.text, lang), OffsetMapping.Identity)
}
