package com.nexcode.app.ui

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.app.AppState

@Composable
fun Dashboard(app: AppState) {
    val ctx = LocalContext.current
    val mi = remember {
        ActivityManager.MemoryInfo().also {
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it)
        }
    }
    val st = remember { StatFs(ctx.filesDir.path) }
    val gb = 1024f * 1024f * 1024f
    val totalStore = st.totalBytes.toFloat()
    val freeStore = st.availableBytes.toFloat()
    val files = remember { app.repo.count() }
    val unsaved = app.tabs.count { it.dirty }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("NEXCODE")
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NxCard {
                Text("Рабочая область", color = NX.Dim, fontSize = 14.sp)
                Text("$files файлов", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Text("${app.tabs.size} открыто · $unsaved не сохранено", color = NX.Dim, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { app.screen = Screen.Project },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NX.Accent, contentColor = Color.Black)
                    ) { Text("Проекты") }
                    if (app.tabs.isNotEmpty()) {
                        Button(
                            onClick = { app.screen = Screen.Editor },
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NX.Card2, contentColor = Color.White)
                        ) { Text("Редактор") }
                    }
                }
            }
            NxCard {
                Text("${Build.MANUFACTURER} ${Build.MODEL}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text(
                    "Android ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT} · ${Runtime.getRuntime().availableProcessors()} cores",
                    color = NX.Dim, fontSize = 14.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val used = 1f - mi.availMem.toFloat() / mi.totalMem.toFloat()
                StatCard("ОЗУ", "%.0f%%".format(used * 100), "свободно %.1f GB".format(mi.availMem / gb), used, Modifier.weight(1f))
                val su = 1f - freeStore / totalStore
                StatCard("Хранилище", "%.0f%%".format(su * 100), "свободно %.0f GB".format(freeStore / gb), su, Modifier.weight(1f))
            }
            if (app.tabs.isNotEmpty()) {
                NxCard {
                    Text("Открытые файлы", color = NX.Dim, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    app.tabs.forEachIndexed { i, t ->
                        Text(
                            (if (t.dirty) "● " else "") + t.file.name,
                            color = if (t.dirty) NX.Amber else Color.White,
                            fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable { app.active = i; app.screen = Screen.Editor }.padding(vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
