package com.nexcode.app

import androidx.compose.runtime.*
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.nexcode.app.data.FileRepo
import com.nexcode.app.ui.Screen
import java.io.File

class EditorTab(val file: File, text: String, val readOnly: Boolean) {
    var value by mutableStateOf(TextFieldValue(text))
    var dirty by mutableStateOf(false)

    fun insert(s: String) {
        if (readOnly) return
        val sel = value.selection
        val t = value.text.replaceRange(sel.min, sel.max, s)
        value = TextFieldValue(t, TextRange(sel.min + s.length))
        dirty = true
    }

    fun move(dx: Int) {
        val p = (value.selection.start + dx).coerceIn(0, value.text.length)
        value = value.copy(selection = TextRange(p))
    }

    fun moveLine(dy: Int) {
        val t = value.text
        val pos = value.selection.start
        val ls = t.lastIndexOf('\n', pos - 1) + 1
        val col = pos - ls
        if (dy < 0) {
            if (ls == 0) return
            val ps = t.lastIndexOf('\n', ls - 2) + 1
            value = value.copy(selection = TextRange(minOf(ps + col, ls - 1)))
        } else {
            val le = t.indexOf('\n', pos)
            if (le < 0) return
            val ne = t.indexOf('\n', le + 1).let { if (it < 0) t.length else it }
            value = value.copy(selection = TextRange(minOf(le + 1 + col, ne)))
        }
    }
}

class AppState(val repo: FileRepo) {
    var screen by mutableStateOf(Screen.Home)
    val tabs = mutableStateListOf<EditorTab>()
    var active by mutableIntStateOf(0)
    var fontSize by mutableFloatStateOf(14f)

    fun open(file: File) {
        val i = tabs.indexOfFirst { it.file == file }
        if (i >= 0) {
            active = i
        } else {
            val (text, ro) = repo.read(file)
            tabs.add(EditorTab(file, text, ro))
            active = tabs.lastIndex
        }
        screen = Screen.Editor
    }

    fun save(t: EditorTab) {
        if (t.readOnly) return
        repo.write(t.file, t.value.text)
        t.dirty = false
    }

    fun close(i: Int) {
        if (i !in tabs.indices) return
        tabs.removeAt(i)
        active = active.coerceAtMost(tabs.lastIndex).coerceAtLeast(0)
    }
}
