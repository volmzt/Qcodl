package com.nexcode.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.nexcode.app.data.FileRepo
import com.nexcode.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { NexTheme { Root() } }
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val app = remember { AppState(FileRepo(ctx.applicationContext)) }
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    Box(Modifier.fillMaxSize().background(NX.Bg)) {
        Box(
            Modifier.fillMaxWidth().height(280.dp)
                .background(Brush.verticalGradient(listOf(Color(0x55FF6600), Color.Transparent)))
        )
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Crossfade(
                targetState = app.screen,
                modifier = Modifier.weight(1f).padding(bottom = if (imeVisible) 0.dp else 96.dp),
                label = "screen"
            ) { s ->
                when (s) {
                    Screen.Home -> Dashboard(app)
                    Screen.Project -> ProjectScreen(app)
                    Screen.Editor -> EditorScreen(app)
                    Screen.Terminal -> TerminalScreen(app)
                    Screen.Plugins -> PluginsScreen()
                    Screen.Settings -> SettingsScreen(app)
                }
            }
        }
        if (!imeVisible) {
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) {
                FloatingNav(app.screen) { app.screen = it }
            }
        }
    }
}
