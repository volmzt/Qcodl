package com.nexcode.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.app.AppState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TerminalScreen(app: AppState) {
    val scope = rememberCoroutineScope()
    val lines = remember { mutableStateListOf("NEXCODE shell (sh). Команды: cd, clear, любые команды Android sh") }
    var cwd by remember { mutableStateOf(app.repo.root) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFE6E6E6))

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex)
    }

    fun run(cmd: String) {
        val c = cmd.trim()
        if (c.isEmpty()) return
        lines.add("$ " + cwd.name + "> " + c)
        if (c == "clear") { lines.clear(); return }
        if (c == "cd" || c.startsWith("cd ")) {
            val arg = c.removePrefix("cd").trim()
            val target = if (arg.isEmpty()) app.repo.root
            else File(if (arg.startsWith("/")) arg else cwd.path + "/" + arg).canonicalFile
            if (target.isDirectory) cwd = target else lines.add("cd: нет такой папки")
            return
        }
        val dir = cwd
        scope.launch(Dispatchers.IO) {
            try {
                val pb = ProcessBuilder("sh", "-c", c).directory(dir).redirectErrorStream(true)
                pb.environment()["HOME"] = app.repo.root.path
                val p = pb.start()
                val br = p.inputStream.bufferedReader()
                while (true) {
                    val l = br.readLine() ?: break
                    withContext(Dispatchers.Main) { lines.add(l) }
                }
                p.waitFor()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { lines.add("ошибка: " + e.message) }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Терминал")
        Column(
            Modifier.weight(1f).padding(horizontal = 20.dp).clip(RoundedCornerShape(24.dp)).background(NX.Card).padding(14.dp)
        ) {
            LazyColumn(Modifier.weight(1f), state = listState) {
                items(lines) { l ->
                    Text(l, style = mono.copy(color = if (l.startsWith("$ ")) NX.Accent else Color(0xFFE6E6E6)))
                }
            }
            Row(Modifier.padding(top = 8.dp)) {
                Text("$ ", style = mono.copy(color = NX.Accent))
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    singleLine = true,
                    textStyle = mono,
                    cursorBrush = SolidColor(NX.Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { val c = input; input = ""; run(c) }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
